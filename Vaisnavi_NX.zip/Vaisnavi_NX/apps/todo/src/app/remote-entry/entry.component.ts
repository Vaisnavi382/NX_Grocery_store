import { Component } from '@angular/core';

@Component({
  selector: 'nx-ng-mfe-todo-entry',
  template: `<nx-ng-mfe-todo-shell></nx-ng-mfe-todo-shell>`,
})
export class RemoteEntryComponent {}
