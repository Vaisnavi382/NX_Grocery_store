declare module 'todo/Module';

declare module 'notes/Module';

declare module 'login/Module';

// declare module 'product-detail/Module';
