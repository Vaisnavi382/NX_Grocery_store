import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { NotesFeatureModule } from '@nx-ng-mfe/notes/feature';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { LauncherModule } from '@nx-ng-mfe/launcher';
import { AuthGuard } from '@nx-ng-mfe/shared/data-access/auth';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    LauncherModule,
    NotesFeatureModule,
    RouterModule.forRoot(
      [
        {
          path: '',
          loadChildren: () =>
            import('@nx-ng-mfe/launcher').then(
              (m) => m.DefaultPageComponentModule
            ),
        },
        {
          path: 'fruits',
          loadChildren: () =>
            import('todo/Module').then((m) => m.RemoteEntryModule),
        },
        {
          path: 'vegetables',
          loadChildren: () =>
            import('notes/Module').then((m) => m.RemoteEntryModule),
          canActivate: [AuthGuard],
          canLoad: [AuthGuard],
        },
        // {
        //   path: 'product-detail',
        //   loadChildren: () =>
        //     import('@nx-ng-mfe/notes/feature').then(
        //       (m) => m.ProductDetailComponent
        //     ),
        // },
        // {
        //   path: 'product-detail',
        //   loadChildren: () =>
        //     import('product-detail/Module').then(
        //       (m) => m.ProductDetailComponentModule
        //     ),
        // },
        {
          path: 'login',
          loadChildren: () =>
            import('login/Module').then((m) => m.RemoteEntryModule),
        },
      ],
      { initialNavigation: 'enabledBlocking' }
    ),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
