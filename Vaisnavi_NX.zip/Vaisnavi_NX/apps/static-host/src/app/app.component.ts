import { Component } from '@angular/core';

@Component({
  selector: 'nx-ng-mfe-root',
  templateUrl: './app.component.html',
})
export class AppComponent {}
