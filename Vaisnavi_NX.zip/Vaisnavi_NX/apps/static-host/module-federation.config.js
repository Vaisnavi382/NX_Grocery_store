module.exports = {
  name: 'static-host',
  remotes: ['todo', 'notes', 'login'],
};
