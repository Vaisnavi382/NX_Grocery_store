import { Component } from '@angular/core';

@Component({
  selector: 'nx-ng-mfe-login-entry',
  template: `<nx-ng-mfe-login-shell></nx-ng-mfe-login-shell>`,
})
export class RemoteEntryComponent {}
