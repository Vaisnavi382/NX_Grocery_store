module.exports = {
  name: 'notes',
  exposes: {
    './Module': 'apps/notes/src/app/remote-entry/entry.module.ts',
  },
};
