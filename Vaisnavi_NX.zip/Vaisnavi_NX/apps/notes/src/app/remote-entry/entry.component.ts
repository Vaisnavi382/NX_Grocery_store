import { Component } from '@angular/core';

@Component({
  selector: 'nx-ng-mfe-notes-entry',
  template: `<nx-ng-mfe-notes-shell></nx-ng-mfe-notes-shell>`,
})
export class RemoteEntryComponent {}
