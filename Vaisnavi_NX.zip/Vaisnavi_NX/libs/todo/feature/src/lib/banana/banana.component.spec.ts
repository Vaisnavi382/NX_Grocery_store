import { ComponentFixture, TestBed } from '@angular/core/testing';

import { bananaComponent } from './banana.component';

describe('bananaComponent', () => {
  let component: bananaComponent;
  let fixture: ComponentFixture<bananaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ bananaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(bananaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
