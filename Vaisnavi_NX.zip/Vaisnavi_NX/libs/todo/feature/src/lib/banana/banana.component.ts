import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import { ButtonComponent } from 'D:/Z004TJCC/multiple/copy/root-html-file/button.component'

@Component({
    selector : 'nx-ng-mfe-banana',
    templateUrl: 'banana.component.html',
    styleUrls: ['./banana.component.css']
})
export class bananaComponent {
    pageTitle = 'banana';
    id = 0;

    constructor(private route: ActivatedRoute,
        private router: Router) {
        // this.id = +this.route.snapshot.paramMap.get('id')!;
        }


}
