import { Component } from '@angular/core';
import { AuthService } from '@nx-ng-mfe/shared/data-access/auth';


@Component({
  selector: 'nx-ng-mfe-todo-shell',
  templateUrl: './shell.component.html',
  styleUrls : ['./shell.component.css']
})
export class ShellComponent {
  app!: boolean;
  ban!: boolean;
  straw!: boolean;
  black!: boolean;

  user$ = this.authService.user$;

  constructor(
    private authService: AuthService
  ) {}

  apple(){
    if (this.app==true){
      this.app=false;
    }
    else
      this.app=true;
  }
  banana(){
    if (this.ban==true){
      this.ban=false;
    }
    else
      this.ban=true;
  }
  strawberry(){
    if (this.straw==true){
      this.straw=false;
    }
    else
      this.straw=true;
  }
  blackberry(){
    if (this.black==true){
      this.black=false;
    }
    else
      this.black=true;
  }
}
