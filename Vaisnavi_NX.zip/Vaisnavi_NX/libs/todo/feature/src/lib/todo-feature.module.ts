import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShellComponent } from './shell/shell.component';
import { CardComponentModule } from '@nx-ng-mfe/shared-ui';
import { bananaComponent} from './banana/banana.component';
import { appleComponent } from './apple/apple.component';
import { blackberryComponent } from './blackberry/blackberry.component';
import { StrawberryComponent } from './strawberry/strawberry.component';



@NgModule({
  imports: [CommonModule, CardComponentModule],
  declarations: [ShellComponent,appleComponent,bananaComponent,blackberryComponent
    ,StrawberryComponent],
  exports: [ShellComponent,appleComponent,bananaComponent,blackberryComponent
    ,StrawberryComponent],
})
export class TodoFeatureModule {}
