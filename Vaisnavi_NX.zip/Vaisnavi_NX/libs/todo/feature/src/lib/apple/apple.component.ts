import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
    selector : 'nx-ng-mfe-apple',
    templateUrl: 'apple.component.html',
    styleUrls: ['apple.component.css']
})
export class appleComponent {
    pageTitle = 'apple';
    id = 0;

    constructor(private route: ActivatedRoute,
        private router: Router) {
        // this.id = +this.route.snapshot.paramMap.get('id')!;
        }

}
