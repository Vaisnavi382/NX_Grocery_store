import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
    selector : 'nx-ng-mfe-blackberry',
    templateUrl: 'blackberry.component.html',
    styleUrls: ['blackberry.component.css']
})
export class blackberryComponent {
    pageTitle = 'blackberry';
    id = 0;

    constructor(private route: ActivatedRoute,
        private router: Router) {
        // this.id = +this.route.snapshot.paramMap.get('id')!;
        }

    onBack(): void {
        this.router.navigate(['/products']);
    }
}
