import { ComponentFixture, TestBed } from '@angular/core/testing';

import { blackberryComponent } from './blackberry.component';

describe('blackberryComponent', () => {
  let component: blackberryComponent;
  let fixture: ComponentFixture<blackberryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ blackberryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(blackberryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
