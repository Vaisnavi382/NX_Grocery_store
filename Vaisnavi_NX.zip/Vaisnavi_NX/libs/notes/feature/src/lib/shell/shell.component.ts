import { Component } from '@angular/core';
import { AuthService } from '@nx-ng-mfe/shared/data-access/auth';

@Component({
  selector: 'nx-ng-mfe-notes-shell',
  templateUrl: './shell.component.html',
  styleUrls : ['shell.component.css']
})
export class ShellComponent {
  // brinjal!: boolean;
  okr!: boolean;
  bottle!: boolean;
  jack!: boolean;


  bri!: boolean;



  // This is required to break the map's reference to allow triggering of change detection
  user$ = this.authService.user$;

  constructor(
    
    private authService: AuthService
  ) {}

  brinjal(){
    if (this.bri==true){
      this.bri=false;
    }
    else
      this.bri=true;
  }

  bottlegourd(){
    if (this.bottle==true){
      this.bottle=false;
    }
    else
      this.bottle=true;
  }
  okra(){
    if (this.okr==true){
      this.okr=false;
    }
    else
      this.okr=true;
  }
  
  jackfruit(){
    if (this.jack==true){
      this.jack=false;
    }
    else
      this.jack=true;
  }


  
}
