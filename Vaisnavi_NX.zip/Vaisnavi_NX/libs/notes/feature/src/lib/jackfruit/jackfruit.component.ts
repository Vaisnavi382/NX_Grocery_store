import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
    selector : 'nx-ng-mfe-jackfruit',
    templateUrl: 'jackfruit.component.html',
    styleUrls: ['jackfruit.component.css']
})
export class JackfruitComponent {
    pageTitle = 'jackfruit';
    id = 0;

    constructor(private route: ActivatedRoute,
        private router: Router) {
        // this.id = +this.route.snapshot.paramMap.get('id')!;
        }

}
