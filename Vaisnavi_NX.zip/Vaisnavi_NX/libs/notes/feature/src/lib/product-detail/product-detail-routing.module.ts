import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { EmptyRouteComponent } from './empty-route/empty-route.component';
import { APP_BASE_HREF } from '@angular/common';
import { ProductDetailComponent } from './product-detail.component';
import { CommonModule } from '@angular/common';


const routes: Routes = [
  { path: '/product-detail', component: ProductDetailComponent },

];

@NgModule({
  imports: [CommonModule, RouterModule.forRoot(routes)],
  declarations: [ProductDetailComponent],
  exports: [ProductDetailComponent],
  providers: [
    { provide: APP_BASE_HREF, useValue: '/' },
  ],
})
export class ProductDetailComponentModule { }
