import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShellComponent } from './shell/shell.component';
import { NotesUiModule } from '@nx-ng-mfe/notes/ui';
import { CardComponentModule } from '@nx-ng-mfe/shared-ui';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { OkraComponent } from './okra/okra.component';

import { BottlegourdComponent } from './bottlegourd/bottlegourd.component';
import { JackfruitComponent } from './jackfruit/jackfruit.component';

@NgModule({
  imports: [CommonModule, NotesUiModule, CardComponentModule],
  declarations: [ShellComponent, ProductDetailComponent,OkraComponent,BottlegourdComponent,
  JackfruitComponent],
  exports: [ShellComponent, ProductDetailComponent,OkraComponent,BottlegourdComponent,
    JackfruitComponent],
})
export class NotesFeatureModule {

}

// export const b= false;