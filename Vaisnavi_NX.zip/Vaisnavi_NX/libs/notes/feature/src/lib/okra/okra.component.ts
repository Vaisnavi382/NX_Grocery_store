import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
    selector : 'nx-ng-mfe-okra',
    templateUrl: 'okra.component.html',
    styleUrls: ['okra.component.css']
})
export class OkraComponent {
    pageTitle = 'okra';
    id = 0;

    constructor(private route: ActivatedRoute,
        private router: Router) {
        // this.id = +this.route.snapshot.paramMap.get('id')!;
        }

   
}
