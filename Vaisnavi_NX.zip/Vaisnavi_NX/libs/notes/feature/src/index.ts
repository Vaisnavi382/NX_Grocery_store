export * from './lib/notes-feature.module';
export * from './lib/shell/shell.component';
export * from './lib/product-detail/product-detail.component';
