import { Component } from '@angular/core';

@Component({
  selector: 'nx-ng-mfe-dock',
  templateUrl: './dock.component.html',
})
export class DockComponent {}
