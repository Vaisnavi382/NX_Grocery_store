import { Component } from '@angular/core';

@Component({
  selector: 'nx-ng-mfe-launcher-shell',
  templateUrl: './shell.component.html',
})
export class ShellComponent {}
