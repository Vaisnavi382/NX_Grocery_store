To run, follow the steps below:

1. Run `npm install`
2. Run `nx serve static-host`
3. Navigate a browser to `http://localhost:4400`
